let popup = document.getElementById('popup1')

function openPopup(){
  popup.classList.add('open-popup1')
}

function closePopup(){
  popup.classList.remove('open-popup1')
}